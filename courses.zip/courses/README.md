# Courses materials

Welcome! 

Be free to copy, modify and redistribute the contents of this repository. I will appreciate if you don´t forget to reference the author :-)